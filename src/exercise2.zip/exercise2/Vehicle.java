package exercise2;

public interface Vehicle {
    public String drive(double distance);
    public void refuel(double liters);
}
